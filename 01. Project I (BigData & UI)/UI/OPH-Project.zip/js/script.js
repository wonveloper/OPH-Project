// DOM 요소 가져옴
const radioButtons = document.querySelectorAll('input[name="guOffice"]');
const mapreportAreaResult = document.querySelector(".safetyIndex__mapreport__result--area");
const safetyIndexCheck = document.querySelector(".safetyIndexCheck");
const safetyIndexModal = document.querySelector(".safetyIndex__modal");
const modalInfoSelectArea = document.querySelector(".modalInfo__selectArea");
const modalInfoSafeyIndex = document.querySelector(".modalInfo__safetyIndex");
const modalCloseBtn = document.querySelector(".safetyIndex__modal__header__close");
const tableTop = document.querySelector("#safetyIndex__modal__table--top tbody");
const tableBottom = document.querySelector("#safetyIndex__modal__table--bottom tbody");

/* 지도 영역에서 자치구를 선택했을 때 해당 자치구를 표시하는 기능 */
function showSelectArea() {
  const selectedRadioButton = document.querySelector('input[name="guOffice"]:checked');

  if (selectedRadioButton) {
    const selectedArea = selectedRadioButton.value;
    mapreportAreaResult.textContent = selectedArea;
    mapreportAreaResult.classList.add("active");
    safetyIndexCheck.classList.add("active");
  } else {
    mapreportAreaResult.textContent = "지역을 선택하세요.";
    mapreportAreaResult.classList.remove("active");
    safetyIndexCheck.classList.remove("active");
  }
}

/* 숫자에 쉼표 추가하는 기능 (테이블 데이터에 적용) */
function addCommansToNumber(number) {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/* 이벤트 리스너 등록 : 지도 영역에서 자치구 선택 시 해당 자치구로 변경 */
radioButtons.forEach((radioButton) => {
  radioButton.addEventListener("change", showSelectArea);
});

/* Highcharts 설정 */
function createHighcharts(data) {
  // Highchart 설정 (top 영역)
  Highcharts.chart("safetyIndex__modal__chart--top", {
    colorAxis: {
      minColor: "#BDE2FF",
      maxColor: "#4070ff",
    },
    series: [
      {
        type: "treemap", // tree map으로 표시
        layoutAlgorithm: "squarified",
        allowDrillToNode: true,
        levels: [
          {
            level: 1,
            dataLabels: {
              enabled: true,
              style: {
                textOutline: "none",
                fontSize: "12px",
              },
              formatter: function () {
                return `${this.point.name}<br> ${this.point.value}%`;
              },
            },
          },
        ],
        // oracle DB에 있는 필드명과 동일하게 작성하여 데이터를 불러옴
        data: [
          {
            name: "1인가구 인구수",
            value: data.oph_population_p,
            colorValue: data.oph_population_p,
          },
          {
            name: "cctv",
            value: data.cctv_p,
            colorValue: data.cctv_p,
          },
          {
            name: "안전비상벨",
            value: data.safetyBell_p,
            colorValue: data.safetyBell_p,
          },
          {
            name: "안전귀갓길",
            value: data.safetyStreet_p,
            colorValue: data.safetyStreet_p,
          },
          {
            name: "지진대피소",
            value: data.shelter_p,
            colorValue: data.shelter_p,
          },
          {
            name: "경찰서",
            value: data.policeOffice_p,
            colorValue: data.policeOffice_p,
          },
          {
            name: "소방서",
            value: data.fireStation_p,
            colorValue: data.fireStation_p,
          },
          {
            name: "응급실",
            value: data.emergencyRoom_p,
            colorValue: data.emergencyRoom_p,
          },
        ],
      },
    ],
    // 차트 제목
    title: {
      text: "안전 항목",
    },
  });

  // table 설정 (top 영역)
  tableTop.innerHTML = ""; // 기존 테이블 내용 비우기

  const topChartData = [
    { rank: data.oph_population_r, name: "1인가구 인구수", total: data.oph_population, percentage: data.oph_population_p },
    { rank: data.cctv_r, name: "cctv", total: data.cctv, percentage: data.cctv_p },
    { rank: data.safetyBell_r, name: "안전비상벨", total: data.safetyBell, percentage: data.safetyBell_p },
    { rank: data.safetyStreet_r, name: "안전귀갓길", total: data.safetyStreet, percentage: data.safetyStreet_p },
    { rank: data.shelter_r, name: "지진대피소", total: data.shelter, percentage: data.shelter_p },
    { rank: data.policeOffice_r, name: "경찰서", total: data.policeOffice, percentage: data.policeOffice_p },
    { rank: data.fireStation_r, name: "소방서", total: data.fireStation, percentage: data.fireStation_p },
    { rank: data.emergencyRoom_r, name: "응급실", total: data.emergencyRoom, percentage: data.emergencyRoom_p },
  ];

  topChartData.forEach((item, index) => {
    const newRow = tableTop.insertRow();
    newRow.innerHTML = `
      <td>${item.rank}</td>
      <td>${item.name}</td>
      <td>${addCommansToNumber(item.total)}</td>
      <td>${item.percentage}%</td>
    `;
  });

  // Highchart 설정 (bottom 영역)
  Highcharts.chart("safetyIndex__modal__chart--bottom", {
    colorAxis: {
      minColor: "#ffcccc", // 연한 빨간색
      maxColor: "#ff0000", // 진한 빨간색
    },
    series: [
      {
        type: "treemap", // tree map으로 표시
        layoutAlgorithm: "squarified",
        allowDrillToNode: true,
        levels: [
          {
            level: 1,
            dataLabels: {
              enabled: true,
              style: {
                textOutline: "none",
                fontSize: "12px",
              },
              formatter: function () {
                return `${this.point.name}<br> ${this.point.value}%`;
              },
            },
          },
        ],
        // oracle DB에 있는 필드명과 동일하게 작성하여 데이터를 불러옴
        data: [
          {
            name: "응급실 이용률",
            value: data.emergencyRoomUsers_p,
            colorValue: data.emergencyRoomUsers_p,
          },
          {
            name: "범죄 발생률",
            value: data.crime_p,
            colorValue: data.crime_p,
          },
          {
            name: "화재 발생률",
            value: data.fire_p,
            colorValue: data.fire_p,
          },
          {
            name: "교통사고 발생률",
            value: data.carAccident_p,
            colorValue: data.carAccident_p,
          },
          {
            name: "보행자 사고 발생률",
            value: data.pedestrianAccident_p,
            colorValue: data.pedestrianAccident_p,
          },
        ],
      },
    ],
    // 차트 제목
    title: {
      text: "위험 항목",
    },
  });

  // table 설정 (bottom 영역)
  tableBottom.innerHTML = ""; // 기존 테이블 내용 비우기

  // 하단 테이블 채우기
  const bottomChartData = [
    { rank: data.emergencyRoomUsers_r, name: "응급실 이용률", total: data.emergencyRoomUsers, percentage: data.emergencyRoomUsers_p },
    { rank: data.crime_r, name: "범죄 발생률", total: data.crime, percentage: data.crime_p },
    { rank: data.fire_r, name: "화재 발생률", total: data.fire, percentage: data.fire_p },
    { rank: data.carAccident_r, name: "교통사고 발생률", total: data.carAccident, percentage: data.carAccident_p },
    { rank: data.pedestrianAccident_r, name: "보행자 사고 발생률", total: data.pedestrianAccident, percentage: data.pedestrianAccident_p },
    // 나머지 항목들 추가
  ];

  bottomChartData.forEach((item, index) => {
    const newRow = tableBottom.insertRow();
    newRow.innerHTML = `
      <td>${item.rank}</td>
      <td>${item.name}</td>
      <td>${addCommansToNumber(item.total)}</td>
      <td>${item.percentage}%</td>
    `;
  });
}

/* 안전지수 모달 해더에 선택한 자치구를 표시하기 */
function showModelInfoSelectArea(selectedArea) {
  if (modalInfoSelectArea) {
    modalInfoSelectArea.textContent = selectedArea || "";
  }
}
/* 안전지수 모달 해더에 안전지수 등급을 표시하기 */
function showModalInfoSafetyIndex(data) {
  if (modalInfoSafeyIndex) {
    modalInfoSafeyIndex.textContent = data.safetyIndex; // 안전지수 등급 할당
  }
}

/* 안전지수 확인 버튼 클릭 시 */
safetyIndexCheck.addEventListener("click", function () {
  
  safetyIndexModal.classList.toggle("active"); // 모달창 활성화

  const selectedRadioButton = document.querySelector('input[name="guOffice"]:checked');
  const selectedArea = selectedRadioButton ? selectedRadioButton.value : null;

  showModelInfoSelectArea(selectedArea); // 선택한 자치구 표시

  if (selectedArea) {
    // Ajax 요청 보내기
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          const responseData = JSON.parse(xhr.responseText);
          showModalInfoSafetyIndex(responseData); // 안전지수 등급 표시
          createHighcharts(responseData); // Highcharts 표시
        } else {
          console.error("Error fetching data from the server.");
        }
      }
    };

    // 요청 보내기
    xhr.open("GET", "safetyIndex.modal.do?guOffice=" + encodeURIComponent(selectedArea));
    xhr.send();
  }
});

/* 모달창 종료 기능 */
function closeModal() {
  safetyIndexModal.classList.remove("active");
  if (modalInfoSelectArea) {
    modalInfoSelectArea.textContent = "";
  }
}

// 모달 닫기 버튼 클릭 시
modalCloseBtn.addEventListener("click", closeModal);

// 모달 외부 클릭 시
window.addEventListener("click", function (event) {
  if (event.target === safetyIndexModal) {
    closeModal();
  }
});
