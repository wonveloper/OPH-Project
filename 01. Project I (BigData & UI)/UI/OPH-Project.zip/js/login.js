/* 아이디, 비밀번호 공백 시 메시지 출력 이벤트 */
  document.addEventListener("DOMContentLoaded", function () {
    const loginButton = document.querySelector(".login__btn");
    const idInput = document.querySelector("#login__id-input");
    const pwInput = document.querySelector("#login__password-input");
    const idErrorMessage = document.querySelector("#wrong__login-id");
    const pwErrorMessage = document.querySelector("#wrong__login-pw");

    loginButton.addEventListener("click", function () {
      idErrorMessage.textContent = "";
      pwErrorMessage.textContent = "";

      if (idInput.value === "") {
        idErrorMessage.textContent = "*아이디를 입력해 주세요";
      }

      if (pwInput.value === "") {
        pwErrorMessage.textContent = "*비밀번호를 입력해 주세요";
      }
    });
  });

