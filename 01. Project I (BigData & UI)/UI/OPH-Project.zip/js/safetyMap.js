/* 로그인 클릭 시 로그인 모달 활성화 이벤트 */
document.addEventListener("DOMContentLoaded", function() {
  const loginModalTriggerNav = document.querySelector(".navbar__user-item a#loginModal");
  const loginModalTriggerSidebar = document.querySelector(".sidebar__login a#loginModal");
  const loginModal = document.querySelector(".loginModal");

  // 클릭 이벤트 핸들러 함수 정의
  function toggleLoginModal() {
    loginModal.classList.toggle("active");
  }

  // 네브바 "로그인" 클릭 시 이벤트 리스너 추가
  loginModalTriggerNav.addEventListener("click", function(event) {
    event.preventDefault(); // 링크의 기본 동작 중단
    toggleLoginModal();
  });

  // 사이드바 "로그인" 클릭 시 이벤트 리스너 추가
  loginModalTriggerSidebar.addEventListener("click", function(event) {
    event.preventDefault(); // 링크의 기본 동작 중단
    toggleLoginModal();
  });

  // 로그인 모달 내 닫기 버튼 클릭 시 이벤트 리스너 추가
  const loginModalCloseButton = loginModal.querySelector(".loginModal__title-close");
  loginModalCloseButton.addEventListener("click", toggleLoginModal);

  // 모달 외부를 클릭할 때 모달 닫기
  window.addEventListener("click", function(event) {
    if (event.target === loginModal) {
      toggleLoginModal();
    }
  });
});


/* map sidebar 버튼 클릭 이벤트 */
const sidebar = document.querySelector('.sidebar');
const sidebarBtn = document.querySelector('.sidebar__toggle');

const toggleSidebar = () => {
    sidebar.classList.toggle('active');
};

sidebarBtn.addEventListener('click', toggleSidebar);


/* tabBox-item 클릭 이벤트 */
// 모든 탭 아이템을 가져옵니다.
const tabItems = document.querySelectorAll('.mapItem__tabBox-item');

// 모든 mapCategory를 가져옵니다.
const mapCategories = document.querySelectorAll('.mapCategory');

// 모든 닫기 버튼을 가져옵니다.
const closeButtons = document.querySelectorAll('.mapCategory__close');

// 각 탭 아이템에 클릭 이벤트 리스너를 추가합니다.
tabItems.forEach((tabItem, index) => {
  tabItem.addEventListener('click', () => {
    // 모든 탭 아이템에서 'active' 클래스를 제거합니다.
    tabItems.forEach(item => item.classList.remove('active'));

    // 모든 mapCategory에서 'active' 클래스를 제거합니다.
    mapCategories.forEach(category => category.classList.remove('active'));

    // 현재 클릭한 탭 아이템에 'active' 클래스를 추가합니다.
    tabItem.classList.add('active');

    // 해당하는 mapCategory에 'active' 클래스를 추가합니다.
    mapCategories[index].classList.add('active');
  });
});

// 각 닫기 버튼에 클릭 이벤트 리스너를 추가합니다.
closeButtons.forEach(closeButton => {
  closeButton.addEventListener('click', () => {
    // 모든 mapCategory에서 'active' 클래스를 제거합니다.
    mapCategories.forEach(category => category.classList.remove('active'));
  });
});
