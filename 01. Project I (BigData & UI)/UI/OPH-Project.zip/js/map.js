/* Map 불러오기 */
var mapContainer = document.getElementById("map");
var mapOption = {
  center: new kakao.maps.LatLng(37.566826, 126.9786567), // 서울 중심 좌표
  level: 3, // 지도의 확대 레벨
};

var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성

var marker = new kakao.maps.CustomOverlay({
  content: '<div class="marker"></div>',
});
marker.setMap(map);

var randomMarkers = [];

function clearMarkers() {
  marker.setMap(null);
  for (var i = 0; i < randomMarkers.length; i++) {
    randomMarkers[i].setMap(null);
  }
  randomMarkers = [];
}

/* 지도 클릭 시 마커를 생성하는 기능 */
kakao.maps.event.addListener(map, "click", function (mouseEvent) {
  var latlng = mouseEvent.latLng;
  clearMarkers();
  marker = new kakao.maps.CustomOverlay({
    content: '<div class="marker"></div>',
    position: latlng,
  });
  marker.setMap(map);
  console.log("클릭한 위치의 [위도] " + latlng.getLat() + " [경도] " + latlng.getLng());
});

// 좌표로 주소 정보 요청
function getAddressFromCoords(lat, lng, rank) {
  var geocoder = new kakao.maps.services.Geocoder();

  geocoder.coord2Address(lng, lat, function (result, status) {
    if (status === kakao.maps.services.Status.OK) {
      var address = result[0].address;
      var gu = address.region_2depth_name;
      var dong = address.region_3depth_name;

      var randomMarker = new kakao.maps.CustomOverlay({
        content:
          '<div class="marker-safetyMap">' +
          '<div class="marker-safetyMap__info">' +
          `<span class="marker-safetyMap__info--rank">${rank}순위</span>` +
          `<div class="marker-safetyMap__info--area">서울시｜<span class="marker__safetyMap__info-area-gu">${gu}</span></div>` +
          `<span class="marker-safetyMap__info--area-dong">${dong}</span>` +
          '<button class="marker-safetyMap__info--btn" onclick="showDetails()">자세히 보기</button>' +
          "</div>" +
          "</div>",
        position: new kakao.maps.LatLng(lat, lng),
      });

      randomMarker.setMap(map);
      randomMarkers.push(randomMarker);
    }
  });
}

/* 주소 검색 기능 */
var ps = new kakao.maps.services.Places();

function searchPlaces() {
  var keyword = document.getElementById("keyword").value;
  ps.keywordSearch(keyword, placesSearchCB);
}

function placesSearchCB(data, status) {
  if (status === kakao.maps.services.Status.OK) {
    var bounds = new kakao.maps.LatLngBounds();

    for (var i = 0; i < data.length; i++) {
      bounds.extend(new kakao.maps.LatLng(data[i].y, data[i].x));
    }

    map.setBounds(bounds);
  }
}

/* 지도 중심 좌표 정보를 나타내는 기능 */
// 주소-좌표 변환 객체 생성
var geocoder = new kakao.maps.services.Geocoder();

// 중심 좌표나 확대 수준이 변경됐을 때 지도 중심 좌표에 대한 주소 정보를 표시하도록 이벤트를 등록
kakao.maps.event.addListener(map, "idle", function () {
  searchAddrFromCoords(map.getCenter(), displayCenterInfo);
});

function searchAddrFromCoords(coords, callback) {
  // 좌표로 행정동 주소 정보 요청
  geocoder.coord2RegionCode(coords.getLng(), coords.getLat(), callback);
}

// 지도 하단에 지도 중심좌표에 대한 주소정보를 표출하는 함수
function displayCenterInfo(result, status) {
  if (status === kakao.maps.services.Status.OK) {
    var location = document.getElementById("location");
    var address = "";

    if (result.length > 0) {
      var si = result[0].region_1depth_name;
      var gu = result[0].region_2depth_name;
      var dong = result[0].region_3depth_name;
      address = si + " " + gu + " " + dong;
    }

    // innerText를 사용하여 주소 정보를 표시하는 요소의 텍스트 값을 변경
    location.innerText = address.trim();
  }
}
