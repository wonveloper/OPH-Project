// 아이디 중복 확인 함수

// 비밀번호 형식 및 일치 여부 확인 함수
function checkPasswordFormat() {
    var passwordInput = document.registration_form.password.value;
    var passwordConfirmInput = document.registration_form.passwordConfirm.value;
    var messageElement = document.getElementById("wrong__join-pw");

    if (passwordInput.length < 8 || !/\d/.test(passwordInput) || !/[a-zA-Z]/.test(passwordInput)) {
        messageElement.innerHTML = "*8자리 이상 영문, 숫자를 포함해 입력해주세요.";
    } else if (passwordInput !== passwordConfirmInput) {
        messageElement.innerHTML = "*비밀번호가 일치하지 않습니다.";
    } else {
        messageElement.innerHTML = "";
    }
}

// 비밀번호 입력 필드에서 입력 중일 때 이벤트 핸들러
document.getElementById("join__password-input").addEventListener("input", checkPasswordFormat);

// 비밀번호 확인 입력 필드에서 입력 중일 때 이벤트 핸들러
document.getElementById("join__password-confirm-input").addEventListener("input", checkPasswordFormat);
