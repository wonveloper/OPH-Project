// DOM 요소들을 가져옴
const radioButtons = document.querySelectorAll('input[name="guOffice"]');
const mapreportAreaResult = document.querySelector(".safetyIndex__mapreport__result--area");
const safetyIndexBtn = document.querySelector(".safetyIndexCheck");
const safetyIndexModal = document.querySelector(".safetyIndex__modal");
const topTableBody = document.querySelector("#safetyIndex__modal__table--top tbody");
const bottomTableBody = document.querySelector("#safetyIndex__modal__table--bottom tbody");
const modalInfoSelectArea = document.querySelector(".modalInfo__selectArea");
const modalCloseBtn = document.querySelector(".safetyIndex__modal__header__close");

// 각종 이벤트 핸들러 함수 정의
/* 지도 영역에서 자치구를 선택했을 때 해당 자치구를 표시 기능 */
function showSelectedArea() {
  const selectedRadioButton = document.querySelector('input[name="guOffice"]:checked');

  if (selectedRadioButton) {
    const selectedArea = selectedRadioButton.nextElementSibling.textContent;
    mapreportAreaResult.textContent = selectedArea;
    mapreportAreaResult.classList.add("active");
    safetyIndexBtn.classList.add("active");
  } else {
    mapreportAreaResult.textContent = "지역을 선택하세요.";
    mapreportAreaResult.classList.remove("active");
    safetyIndexBtn.classList.remove("active");
  }
}

/* 모달창 종료 기능 */
function closeModal() {
  safetyIndexModal.classList.remove("active");
  if (modalInfoSelectArea) {
    modalInfoSelectArea.textContent = "";
  }
}

// 숫자에 쉼표 추가하는 함수
function addCommasToNumber(number) {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// 이벤트 리스너 등록
/* 지도 영역에서 자치구 선택 시 */
radioButtons.forEach((radioButton) => {
  radioButton.addEventListener("change", showSelectedArea);
});

/* 안전지수 확인 버튼을 클릭 시 */
safetyIndexBtn.addEventListener("click", function () {
  // 버튼 클릭 시 모달 열기
  safetyIndexModal.classList.toggle("active");

  // 선택한 자치구 정보 가져오기
  const selectedRadioButton = document.querySelector('input[name="guOffice"]:checked');
  const selectedArea = selectedRadioButton ? selectedRadioButton.value : null;

  // 차트 데이터 가져오기
  const selectedData = percentage[selectedArea];
  const categories = {
    top: ["인구밀도", "cctv", "안전비상벨", "안전귀갓길", "지진대피소", "경찰서", "소방서", "응급실"],
    bottom: ["응급실 이용자수", "범죄 발생건수", "화재 발생건수", "교통사고 발생건수"],
  };

  // 테이블 데이터 가져오기
  const rankDataRow = rankData[selectedArea];
  const totalDataRow = total[selectedArea];
  const percentageDataRow = percentage[selectedArea];

  if (modalInfoSelectArea) {
    modalInfoSelectArea.textContent = selectedArea || "";
  }

  // High Charts 나타내기
  function generateChartData(categoryArray, colorAxisMinColor) {
    return categoryArray.map((category, index) => ({
      name: category,
      value: selectedData[index],
      colorValue: selectedData[index],
      tooltip: {
        pointFormat: `<b>${category}</b>: {point.value}%`,
      },
      dataLabels: {
        enabled: true,
        format: `${category}<br> {point.value}%`,
        style: {
          textOutline: "none",
        },
      },
    }));
  }

  // High Charts (top) 옵션
  const chartOptionsTop = {
    colorAxis: {
      minColor: "#BDE2FF",
      maxColor: "#4070ff",
    },
    series: [
      {
        type: "treemap",
        layoutAlgorithm: "squarified",
        clip: false,
        data: generateChartData(categories.top),
      },
    ],
    title: {
      text: "안전 항목",

      style: {
        fontSize: "18px", // 원하는 글자 크기로 설정
      },
    },
  };

  Highcharts.chart("safetyIndex__modal__chart--top", chartOptionsTop);

  // 테이블 데이터 삽입
  topTableBody.innerHTML = ""; // 기존 내용 초기화

  for (let i = 0; i < rankDataRow.length - 4; i++) {
    const newRow = document.createElement("tr");
    newRow.innerHTML = `
      <td>${rankDataRow[i]}</td>
      <td>${categories.top[i]}</td>
      <td>${addCommasToNumber(totalDataRow[i])}</td>
      <td>${percentageDataRow[i]}%</td>
    `;
    topTableBody.appendChild(newRow);
  }

  // High Charts (bottom) 옵션
  const chartOptionsBottom = {
    colorAxis: {
      minColor: "#ffcccc", // 연한 빨간색
      maxColor: "#ff0000", // 진한 빨간색
    },
    series: [
      {
        type: "treemap",
        layoutAlgorithm: "squarified",
        clip: false,
        data: generateChartData(categories.bottom, "#ff0000"),
      },
    ],
    title: {
      text: "위험 항목",

      style: {
        fontSize: "18px", // 원하는 글자 크기로 설정
      },
    },
  };

  Highcharts.chart("safetyIndex__modal__chart--bottom", chartOptionsBottom);

  // 테이블 데이터 삽입
  bottomTableBody.innerHTML = ""; // 기존 내용 초기화

  for (let i = 8; i < rankDataRow.length; i++) {
    const newRow = document.createElement("tr");
    newRow.innerHTML = `
      <td>${rankDataRow[i - 8]}</td>
      <td>${categories.bottom[i - 8]}</td>
      <td>${addCommasToNumber(totalDataRow[i - 8])}</td>
      <td>${percentageDataRow[i - 8]}%</td>
    `;
    bottomTableBody.appendChild(newRow);
  }
});

// 모달 닫기 버튼 클릭 시
modalCloseBtn.addEventListener("click", closeModal);

// 모달 외부 클릭 시
window.addEventListener("click", function (event) {
  if (event.target === safetyIndexModal) {
    closeModal();
  }
});

// 소계 데이터 세팅
const total = {
  강남구: [27923, 6495, 4231, 248, 120, 23, 7, 4, 16451, 6280, 437, 173],
  강동구: [19398, 3086, 1037, 150, 54, 17, 7, 3, 11547, 3392, 194, 208],
  강북구: [13977, 3184, 391, 392, 51, 15, 5, 3, 7884, 2068, 155, 256],
  강서구: [41228, 3151, 964, 119, 116, 13, 7, 4, 16541, 3508, 223, 783],
  관악구: [85559, 4029, 2033, 198, 80, 19, 5, 4, 19654, 4032, 305, 359],
  광진구: [34062, 3370, 927, 131, 38, 13, 4, 2, 11241, 3144, 145, 420],
  구로구: [21300, 4013, 1049, 63, 47, 18, 7, 2, 8104, 3098, 222, 266],
  금천구: [20478, 2498, 817, 51, 47, 13, 3, 1, 4502, 2116, 214, 533],
  노원구: [17377, 2284, 445, 195, 79, 17, 6, 3, 14231, 3144, 169, 403],
  도봉구: [8710, 1994, 398, 98, 55, 10, 5, 1, 10567, 1791, 159, 248],
  동대문구: [32864, 2592, 842, 180, 50, 21, 6, 4, 10124, 2840, 173, 306],
  동작구: [37354, 2404, 626, 175, 44, 18, 5, 2, 12840, 2197, 187, 265],
  마포구: [34561, 2500, 860, 88, 65, 16, 7, 1, 10245, 3117, 250, 308],
  서대문구: [26052, 2928, 401, 137, 46, 12, 5, 2, 7265, 2094, 223, 391],
  서초구: [17474, 3180, 557, 170, 67, 21, 7, 1, 11058, 3859, 216, 313],
  성동구: [19746, 3627, 900, 68, 61, 16, 5, 2, 8852, 2019, 215, 216],
  성북구: [30698, 4014, 1042, 271, 64, 26, 5, 1, 9876, 2145, 158, 279],
  송파구: [30705, 2805, 880, 150, 90, 22, 7, 2, 12457, 4502, 350, 327],
  양천구: [11632, 3627, 821, 62, 84, 16, 6, 3, 9048, 2879, 159, 296],
  영등포구: [34260, 3896, 1185, 143, 71, 16, 6, 9, 11548, 3994, 249, 443],
  용산구: [16657, 2531, 589, 143, 46, 13, 6, 1, 7548, 2574, 207, 231],
  은평구: [20816, 4103, 611, 115, 61, 22, 5, 3, 10895, 3159, 217, 296],
  종로구: [12100, 1812, 461, 159, 45, 25, 7, 4, 4780, 2658, 191, 281],
  중구: [9619, 2026, 648, 100, 18, 20, 7, 2, 4701, 2654, 190, 230],
  중랑구: [18429, 3856, 1131, 143, 52, 18, 5, 3, 8240, 3017, 188, 163],
};

// 비율 데이터 세팅
const percentage = {
  강남구: [4.3, 8.1, 17.7, 6.6, 7.7, 5.2, 4.8, 6, 6.3, 8.2, 8.1, 2.2],
  강동구: [3, 3.9, 4.4, 4, 3.5, 3.9, 4.8, 4.5, 4.4, 4.5, 3.6, 2.6],
  강북구: [2.2, 4, 1.6, 10.5, 3.3, 3.4, 3.5, 4.5, 3, 2.7, 2.9, 3.2],
  강서구: [6.4, 3.9, 4, 3.2, 7.5, 3, 4.8, 6, 6.4, 4.6, 4.1, 9.8],
  관악구: [13.3, 5, 8.5, 5.3, 5.2, 4.3, 3.5, 6, 7.6, 5.3, 5.7, 4.5],
  광진구: [5.3, 4.2, 3.9, 3.5, 2.5, 3, 2.8, 3, 4.3, 4.1, 2.7, 5.3],
  구로구: [3.3, 5, 4.4, 1.7, 3, 4.1, 4.8, 3, 3.1, 4.1, 4.1, 3.3],
  금천구: [3.2, 3.1, 3.4, 1.4, 3, 3, 2.1, 1.5, 1.7, 2.8, 4, 6.7],
  노원구: [2.7, 2.9, 1.9, 5.2, 5.1, 3.9, 4.1, 4.5, 5.5, 4.1, 3.1, 5],
  도봉구: [1.4, 2.5, 1.7, 2.6, 3.6, 2.3, 3.5, 1.5, 4.1, 2.4, 3, 3.1],
  동대문구: [5.1, 3.2, 3.5, 4.8, 3.2, 4.8, 4.1, 6, 3.9, 3.7, 3.2, 3.8],
  동작구: [5.8, 3, 2.6, 4.7, 2.8, 4.1, 3.5, 3, 4.9, 2.9, 3.5, 3.3],
  마포구: [5.4, 3.1, 3.6, 2.4, 4.2, 3.6, 4.8, 1.5, 3.9, 4.1, 4.6, 3.9],
  서대문구: [4.1, 3.7, 1.7, 3.7, 3, 2.7, 3.5, 3, 2.8, 2.8, 4.1, 4.9],
  서초구: [2.7, 4, 2.3, 4.5, 4.3, 4.8, 4.8, 1.5, 4.3, 5.1, 4, 3.9],
  성동구: [3.1, 4.5, 3.8, 1.8, 3.9, 3.6, 3.5, 3, 3.4, 2.7, 4, 2.7],
  성북구: [4.8, 5, 4.4, 7.2, 4.1, 5.9, 3.5, 1.5, 3.8, 2.8, 2.9, 3.5],
  송파구: [4.8, 3.5, 3.7, 4, 5.8, 5, 4.8, 3, 4.8, 5.9, 6.5, 4.1],
  양천구: [1.8, 4.5, 3.4, 1.7, 5.4, 3.6, 4.1, 4.5, 3.5, 3.8, 3, 3.7],
  영등포구: [5.3, 4.9, 5, 3.8, 4.6, 3.6, 4.1, 13.4, 4.4, 5.2, 4.6, 5.5],
  용산구: [2.6, 3.2, 2.5, 3.8, 3, 3, 4.1, 1.5, 2.9, 3.4, 3.8, 2.9],
  은평구: [3.2, 5.1, 2.6, 3.1, 3.9, 5, 3.5, 4.5, 4.2, 4.1, 4, 3.7],
  종로구: [1.9, 2.3, 1.9, 4.2, 2.9, 5.7, 4.8, 6, 1.8, 3.5, 3.5, 3.5],
  중구: [1.5, 2.5, 2.7, 2.7, 1.2, 4.6, 4.8, 3, 1.8, 3.5, 3.5, 2.9],
  중랑구: [2.9, 4.8, 4.7, 3.8, 3.4, 4.1, 3.5, 4.5, 3.2, 4, 3.5, 2],
};

// 순위 데이터 세팅
const rankData = {
  강남구: [10, 1, 1, 3, 1, 3, 5, 4, 3, 1, 1, 24],
  강동구: [16, 14, 7, 10, 14, 13, 5, 9, 8, 7, 14, 23],
  강북구: [21, 11, 25, 1, 16, 19, 19, 9, 20, 23, 24, 18],
  강서구: [2, 13, 8, 17, 2, 21, 5, 4, 2, 6, 6, 1],
  관악구: [1, 3, 2, 4, 5, 9, 19, 4, 1, 3, 3, 7],
  광진구: [6, 10, 9, 16, 24, 21, 24, 16, 9, 9, 25, 4],
  구로구: [12, 5, 5, 23, 18, 11, 5, 16, 19, 12, 8, 16],
  금천구: [14, 20, 15, 25, 18, 21, 25, 22, 25, 21, 12, 2],
  노원구: [19, 22, 22, 5, 6, 13, 12, 9, 4, 9, 20, 5],
  도봉구: [25, 24, 24, 20, 13, 25, 19, 22, 12, 25, 21, 19],
  동대문구: [7, 17, 13, 6, 17, 6, 12, 4, 14, 15, 19, 11],
  동작구: [3, 21, 17, 7, 23, 11, 19, 16, 5, 19, 18, 17],
  마포구: [4, 19, 12, 21, 9, 16, 5, 22, 13, 11, 4, 10],
  서대문구: [11, 15, 23, 15, 20, 24, 19, 16, 22, 22, 6, 6],
  서초구: [18, 12, 20, 8, 8, 6, 5, 22, 10, 5, 10, 9],
  성동구: [15, 8.5, 10, 22, 11, 16, 19, 16, 17, 24, 11, 22],
  성북구: [9, 4, 6, 2, 10, 1, 19, 22, 15, 20, 23, 15],
  송파구: [8, 16, 11, 10, 3, 4, 5, 16, 6, 2, 2, 8],
  양천구: [23, 8.5, 14, 24, 4, 16, 12, 9, 16, 14, 21, 12],
  영등포구: [5, 6, 3, 13, 7, 16, 12, 1, 7, 4, 5, 3],
  용산구: [20, 18, 19, 13, 20, 21, 12, 22, 21, 18, 13, 20],
  은평구: [13, 2, 18, 18, 11, 4, 19, 9, 11, 8, 9, 12],
  종로구: [22, 25, 21, 9, 22, 2, 5, 4, 23, 16, 15, 14],
  중구: [24, 23, 16, 19, 25, 8, 5, 16, 24, 17, 16, 21],
  중랑구: [17, 7, 4, 13, 15, 11, 19, 9, 18, 13, 17, 25],
};
